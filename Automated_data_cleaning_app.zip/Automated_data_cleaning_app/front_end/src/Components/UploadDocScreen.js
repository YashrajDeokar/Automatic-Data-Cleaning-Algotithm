import React, { useState } from 'react';
import Excel from './Excel';
import SQL_Form from './SQL_Form';
import TopBar from './TopBar';
import { BrowserRouter as Router, Route,Routes } from 'react-router-dom';




function UploadDocScreen(){
  
return(
   <Router>
   <div style={{display:"flex",justifyContent:"center",width:"100vw",height:"100vh",alignItems:"center",flexDirection:"column"}}>
  <TopBar/>
    <div style={{background:"#ffffff",height:"80vh",width:"80vw"}}>
    <Routes>
    <Route exact path="/" element={<Excel/>} />
        <Route path="/SQL" element={<SQL_Form Tp="SQL"/>} />
        <Route path="/MongoDb" element={<SQL_Form Tp="Mongo"/>} />
        </Routes>
</div>
   </div>
   </Router>
)
}

export default UploadDocScreen