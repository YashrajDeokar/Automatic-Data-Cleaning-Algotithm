import pandas as pd 

def find_outliers(column):
    Q1 = column.quantile(0.25)
    Q3 = column.quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    outliers = (column < lower_bound) | (column > upper_bound)
    return outliers

def remove_outliers(df):
    columns = df.columns.tolist()
    for column in columns:
        if df[column].dtype == 'int':   
            outliers_df=find_outliers(column)
            df = df[~outliers_df.any(axis=1)]

    return df