import React,{props, useEffect, useState} from "react";

function SQL_Form(props){
    
return(
    <div style={{justifyContent:"center",alignItems:"center",display:"flex",flexDirection:"column"}}>
<form  style={{display:"flex",flexDirection:"row",justifyContent:"center",alignItems:"center"}}>
    <div style={{display:"flex",flexDirection:"column",}}>
    <label style={{marginTop:"20px"}}>UserName : 
        
    </label>
    <label style={style.LabelStyle}>Password : 
        
    </label>
    <label style={style.LabelStyle}>Port No : 
        
    </label>
    </div>
    <div style={{display:"flex",flexDirection:"column",}}>
        <input style={{marginTop:"20px",marginLeft:"5px"}}/>
        <input style={{marginTop:"10px",marginLeft:"5px"}}/>
        <input style={{marginTop:"10px",marginLeft:"5px"}}/>
    </div>
   
</form>
<button style={{width:"100px",height:"30px",marginTop:"20px"}}>Clean</button>
    </div>
)
}

const style={LabelStyle:{
    marginTop:"10px"
}}

export default SQL_Form