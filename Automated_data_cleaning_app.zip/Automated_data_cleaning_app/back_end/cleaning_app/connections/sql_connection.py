import mysql.connector
import pandas as pd

def connect(localhost,username,password):
    db = mysql.connector.connect(
        localhost=localhost,
        username=username,
        password=password
    )
    database_cursor = db.cursor()
    database_cursor.execute("SHOW TABLES")
    tables = database_cursor.fetchall()
    if db.is_connected:
        print("database is connected")
        for table in tables:
            query = "select * from {table}"
            df=pd.read_sql(query,db)


    else:
        print("something went wrong")

    database_cursor.close()
    db.close()
