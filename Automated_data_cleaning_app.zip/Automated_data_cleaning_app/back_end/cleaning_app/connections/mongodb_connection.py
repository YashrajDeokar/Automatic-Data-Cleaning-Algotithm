import pandas as pd
from pymongo import MongoClient


def mongo_connected(url,database_name):
    mongo_connection = MongoClient(url)
    db = mongo_connection[database_name]
    if db is not None:
        all_collections = db.list_collection_names
        for collection in all_collections:
            cursor = collection.find()
            df = pd.DataFrame(list(cursor))
            cursor.close()


    else:
        print("database does not exist or the credentials entered by you are incorrect")
    
    mongo_connection.close()


