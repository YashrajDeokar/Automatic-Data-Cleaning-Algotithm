from django.urls import path,include
from cleaning_app import views


urlpatterns = [
    path('/clean',views.cleaningAlgo,name="cleaning"),
]