import logo from './logo.svg';
import './App.css';
import UploadDocScreen from './Components/UploadDocScreen';
import LoadingScreen from './Components/LoadingScreen';

function App() {
  return (
  <div>
    <UploadDocScreen/>
  </div>
  );
}

export default App;
