import React from "react";
import Loadingicon from './Loadingicon.gif'

function LoadingScreen(){

    return(
        <div style={{justifyContent:"center",alignContent:"center",marginTop:'300px',marginLeft:'730px',display:"flex",flexDirection:"column"}}>
<img src={Loadingicon} style={{height:"80px",width:"80px"}}/>
<>please wait</>

        </div>
    )
}

export default LoadingScreen