import pandas as pd


def checkNull(df):
    null_vals = df.isnull().sum()
    for null_val in null_vals:
        if null_val != 0:
            return True
        
    return False
def handling_null(df):
    if checkNull(df):
        df=df.interpolate()
    if checkNull(df):
        df = df.fillna(df.mean())

    df=df.dropna()
    return df
    