import React ,{useState} from "react";
import { Link } from "react-router-dom";

function TopBar(){
    const[BarColor1,setBarColor1]=useState("black")
    const[BarColor2,setBarColor2]=useState("black")
    const[BarColor3,setBarColor3]=useState("black")
return(
    <div style={{background:"black",height:"7vh",width:"80vw",justifyContent:"center",alignContent:"center",display:"flex",flexDirection:"row"}}>
    <div style={{display:"flex",flexDirection:"column"}}>
   <Link style={{background:{BarColor1},color:"white",marginRight:"0px",width:"100px",height:"50px",display:"flex",justifyContent:"center",alignItems:"center",textDecoration:"None"}}  onClick={()=>{
       setBarColor1("white")
    }} to="/">Excel</Link>
    </div>
    <div style={{display:"flex",flexDirection:"column"}}>
    <Link style={{background:{BarColor2},color:"white",marginLeft:"0px",width:"100px",height:"50px",display:"flex",justifyContent:"center",alignItems:"center",textDecoration:"None"}}  onClick={()=>{
       setBarColor2("white")
    }} to="/SQL">SQL</Link>
    </div>
    <div style={{display:"flex",flexDirection:"column"}}>
    <Link style={{background:{BarColor3},color:"white",marginLeft:"0px",width:"100px",height:"50px",display:"flex",justifyContent:"center",alignItems:"center",textDecoration:"None"}}  onClick={()=>{
       setBarColor3("white")
    }} to="/MongoDb">MongoDB</Link>
    </div>
        </div>
)
}

export default TopBar