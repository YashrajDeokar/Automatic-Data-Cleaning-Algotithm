import React, { useState, useEffect } from 'react';

function Excel() {
  const [fileName, setFileName] = useState("Upload .csv/.xlsx");
  const [file, setFile] = useState(null);

  useEffect(() => {
    if (file) {
      setFileName(file.name);
    } else {
      setFileName("Upload .csv/.xlsx");
    }
  }, [file]);

  const handleFileInputChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
  };

  return (
    <div style={{ justifyContent: "center", display: "flex", alignItems: "center", flexDirection: "column", marginTop: "20px" }}>
      <p>{fileName}</p>
      <input
        type="file"
        accept=".csv, .xlsx"
        onChange={handleFileInputChange} style={{ marginTop: "20px", width: "20vw", height: "10vh" }} />
      {file !== null ? (
        <form method='POST'>
          <div style={{ justifyContent: "center", display: "flex", alignItems: "center", flexDirection: "column", marginTop: "0px" }}>
            <input type='text' enterKeyHint='Target attribute(optional)' style={{ visibility: "", width: "5vw", marginTop: "25px" }} />
            <button style={{ marginTop: "10px" }}>Clean</button>
          </div>
        </form>
      ) : null}
    </div>
  )
}

export default Excel;
