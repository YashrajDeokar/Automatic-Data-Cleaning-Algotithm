import pandas as pd



def duplicate_values(df):
    duplicated_values=pd.duplicated().sum()
    if duplicated_values != 0:
        df=df.drop_duplicates()
    
    return df