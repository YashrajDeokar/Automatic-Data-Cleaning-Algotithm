from django.shortcuts import render,HttpResponse

# Create your views here.


def cleaningAlgo(request):
   return HttpResponse("this is the ddata cleaning app")

